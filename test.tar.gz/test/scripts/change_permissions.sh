#!/bin/bash
chmod -R 755 /var/www/html/WordPress
