#!/bin/bash
apt-get install -y mysql-server php5 apache2
apt-get install -y php5-mysql
